# Lumen

A dark, curated film browser for silent comedy and classic cinema.

Rebuilt from the Lumen Home screen: featured *Sherlock Jr.* (1924), the **Comic genius** row, and bottom tabs for Home, Search, and List.

## Open it

Open `index.html` in a browser. No install step.

## What it does

- Home: featured title + horizontal Comic genius row
- Search: filter by title, year, or person
- List: save films in the browser (`localStorage`)
- Detail: short note and add/remove from your list

Catalog is public-domain silent comedy (Keaton, Lloyd, Chaplin). Family-friendly.

## Files

- `index.html` — shell
- `styles.css` — layout matching the screenshot
- `app.js` — screens, search, list
